from __future__ import annotations

import argparse
import json
import logging
import os
import re
from pathlib import Path
from typing import Any

import torch

from moe_exp.correlation_pipeline.benchmarks import BENCHMARKS, DEFAULT_BENCHMARKS
from moe_exp.correlation_pipeline.defaults import DEFAULT_FORWARD_MODEL, DEFAULT_GENERATION_MODEL
from moe_exp.correlation_pipeline.features import (
    FEATURE_SCHEMA_VERSION,
    compute_layer_features,
    json_safe_features,
)
from moe_exp.jsonl import iter_jsonl
from moe_exp.models.loader import QUANTIZATION_CHOICES, load_model_and_tokenizer
from moe_exp.models.routing_extraction import process_file

logger = logging.getLogger(__name__)
_SAFE_FILENAME = re.compile(r"[^A-Za-z0-9_.-]+")
DEFAULT_PROBE_RESULTS = Path(
    "results/probeTest/qwen3.5-35b-a3b-gptq-int4/probes/results.json"
)


def _model_slug(model: str) -> str:
    return _SAFE_FILENAME.sub("--", model).strip("-")


def _write_json_atomic(payload: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def load_probe_layers(path: Path, num_router_layers: int) -> tuple[list[int], list[int]]:
    """Load the union of accuracy-selected probe indices compatible with routers."""
    if not path.is_file():
        raise FileNotFoundError(f"Missing probe results: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    best = payload.get("best_by_target")
    if not isinstance(best, dict) or not best:
        raise ValueError(f"Probe results have no non-empty best_by_target mapping: {path}")
    try:
        requested = sorted({int(row["layer_idx"]) for row in best.values()})
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError(f"Invalid best_by_target layer entries in {path}") from error
    compatible = [index for index in requested if 0 <= index < num_router_layers]
    excluded = [index for index in requested if index not in compatible]
    if not compatible:
        raise ValueError(
            f"None of the probe-selected indices {requested} match router layers "
            f"0..{num_router_layers - 1}. Use --all-router-layers to explicitly "
            "override the fixed selection."
        )
    return compatible, excluded


def _storage_summary(output_path: Path) -> tuple[int, dict[str, int]]:
    projected_raw = 0
    persisted_tensors = 0
    persisted_raw = 0
    retained_tokens = 0
    trace_count = 0
    for record in iter_jsonl(output_path):
        trace_count += 1
        audit = record.get("metadata", {}).get("correlation_storage", {})
        projected_raw += int(audit.get("projected_raw_payload_bytes", 0))
        persisted_tensors += int(audit.get("persisted_tensor_bytes", 0))
        persisted_raw += int(audit.get("persisted_raw_tensor_bytes", 0))
        retained_tokens += int(audit.get("tokens_retained", 0))
    dataset_files = sum(
        path.stat().st_size for path in output_path.parent.rglob("*") if path.is_file()
    )
    return trace_count, {
        "retained_tokens": retained_tokens,
        "projected_raw_payload_bytes": projected_raw,
        "persisted_tensor_bytes": persisted_tensors,
        "persisted_raw_tensor_bytes": persisted_raw,
        "dataset_files_bytes": dataset_files,
        "raw_payload_bytes_avoided": max(projected_raw - persisted_raw, 0),
    }


def extract_all(args: argparse.Namespace, *, model_and_tokenizer=None) -> list[dict[str, Any]]:
    from moe_exp.correlation_pipeline.spans import SPAN_SCHEMA_VERSION
    from moe_exp.correlation_pipeline.views import compute_views, position_reference

    modes = getattr(args, "views", None)
    if modes and "class" in modes and getattr(args, "annotation_dir", None) is None:
        raise ValueError("--views class requires --annotation-dir")
    if getattr(args, "position_bins", 10) < 1:
        raise ValueError("--position-bins must be positive")
    generation_root = args.generation_dir / _model_slug(args.generation_model)
    output_root = args.output_dir / _model_slug(args.model_id)
    inputs: list[tuple[str, Path, Path]] = []
    for dataset in args.datasets:
        input_path = generation_root / dataset / "traces.jsonl"
        if not input_path.is_file() or input_path.stat().st_size == 0:
            raise FileNotFoundError(
                f"Missing generated traces for {dataset}: {input_path}. "
                "Run the correlation generation stage first."
            )
        manifest_path = generation_root / dataset / "manifest.json"
        if not manifest_path.is_file():
            raise FileNotFoundError(f"Missing generation manifest for {dataset}: {manifest_path}")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        generated_target = manifest.get("target_model_id")
        if generated_target != args.model_id:
            raise ValueError(
                f"Generated {dataset} traces target {generated_target!r}, but forward extraction "
                f"requested {args.model_id!r}. Use the same target model."
            )
        output_path = output_root / dataset / "traces_with_routing.jsonl"
        inputs.append((dataset, input_path, output_path))

    logger.info("Loading forward-pass checkpoint %s once for %d datasets", args.model_id, len(inputs))
    model, tokenizer = model_and_tokenizer or load_model_and_tokenizer(
        args.model_id,
        device=args.device,
        trust_remote_code=args.trust_remote_code,
        quantization=args.quantization,
        revision=getattr(args, "revision", None),
        local_files_only=getattr(args, "local_files_only", False),
        offload_folder=str(output_root / "offload"),
    )
    from moe_exp.correlation_pipeline.provenance import forward_provenance
    provenance = forward_provenance(
        model, tokenizer, revision=getattr(args, "revision", None),
        local_files_only=getattr(args, "local_files_only", False),
    )
    text_config = getattr(model.config, "text_config", None)
    num_router_layers = getattr(text_config, "num_hidden_layers", None)
    if num_router_layers is None:
        num_router_layers = getattr(model.config, "num_hidden_layers", None)
    if num_router_layers is None:
        raise ValueError("Could not determine the forward model's number of layers")
    from moe_exp.models.router_adapters import available_router_layers
    available = available_router_layers(model)
    if getattr(args, "all_router_layers", False):
        layer_indices = available if available is not None else list(range(int(num_router_layers)))
        excluded_probe_indices = []
    else:
        layer_indices, excluded_probe_indices = load_probe_layers(
            args.probe_results, int(num_router_layers)
        )
        if available is not None:
            excluded_probe_indices += [index for index in layer_indices if index not in available]
            layer_indices = [index for index in layer_indices if index in available]
    if not layer_indices:
        raise ValueError(
            "None of the unchanged probe indices has a router in this model. "
            f"Available decoder router layers: {available}. "
            "Use --all-router-layers to explicitly override the fixed selection."
        )
    logger.info("Retaining decoder router layers: %s", layer_indices)
    if excluded_probe_indices:
        logger.warning(
            "Excluding probe hidden-state indices without a corresponding router layer: %s",
            excluded_probe_indices,
        )
    summaries: list[dict[str, Any]] = []
    reference = None
    if modes and "position" in modes:
        logger.info("Computing fixed model-corpus position reference from all supplied generations")
        reference = position_reference([item[1] for item in inputs], tokenizer, args.model_id, args.position_bins)
        _write_json_atomic(reference, output_root / "position_reference.json")

    def reduce_views(trace, router, hidden, experts, layers):
        return compute_views(trace, tokenizer, router, hidden, experts, layers, modes=modes,
                             reference=reference, max_geometry_tokens=args.max_geometry_tokens)

    def reduce_features(
        router_logits: torch.Tensor,
        hidden_states: torch.Tensor | None,
        selected_experts: torch.Tensor,
        selected_layers: list[int] | None,
    ) -> dict[str, Any]:
        return json_safe_features(
            compute_layer_features(
                router_logits,
                hidden_states,
                selected_experts,
                max_geometry_tokens=args.max_geometry_tokens,
                layer_indices=selected_layers,
            )
        )

    try:
        for dataset, input_path, output_path in inputs:
            logger.info("Extracting %s", dataset)
            view_kwargs = {}
            if modes:
                annotations = None
                if "class" in modes:
                    annotation_path = args.annotation_dir / _model_slug(args.generation_model) / dataset / "annotations.jsonl"
                    annotations = {}
                    for annotation in iter_jsonl(annotation_path):
                        key = (annotation.get("source_model", args.generation_model),
                               annotation["dataset"], annotation["problem_id"],
                               annotation.get("sample_id", 0))
                        if "sample_id" not in annotation:
                            key = annotation["problem_id"]  # existing per-trace annotation files
                        if key in annotations:
                            raise ValueError(f"Duplicate annotation in {annotation_path}")
                        if annotation.get("status") != "complete":
                            raise ValueError(f"Incomplete annotation in {annotation_path}")
                        annotations[key] = annotation
                view_kwargs = {"view_reducer": reduce_views,
                               "view_config": {"schema_version": SPAN_SCHEMA_VERSION,
                                               "modes": sorted(modes), "position_reference": reference},
                               "trace_annotations": annotations}
            if getattr(args, "dynamics", False):
                from moe_exp.correlation_pipeline.dynamics import SCHEMA_VERSION as DYNAMICS_SCHEMA
                from moe_exp.correlation_pipeline.dynamics.common import DEFAULT_CONFIG
                from moe_exp.correlation_pipeline.dynamics.routing import reduce_trace
                from moe_exp.correlation_pipeline.provenance import code_provenance
                view_kwargs.update(
                    dynamics_reducer=reduce_trace,
                    dynamics_config={"schema_version": DYNAMICS_SCHEMA,
                                     **DEFAULT_CONFIG, "code": code_provenance()},
                )
            execution = process_file(
                input_path=input_path,
                model_id=args.model_id,
                output_path=output_path,
                limit=args.limit,
                top_k=args.top_k,
                extract_hidden_states=not args.router_only,
                quantization=args.quantization,
                model=model,
                tokenizer=tokenizer,
                strict_top_k=True,
                layer_indices=layer_indices,
                save_expert_weights=False,
                feature_reducer=reduce_features,
                feature_schema_version=FEATURE_SCHEMA_VERSION,
                feature_config={"max_geometry_tokens": args.max_geometry_tokens},
                save_raw_tensors=args.save_raw_tensors,
                forward_provenance=provenance,
                **view_kwargs,
            )
            if not output_path.is_file() or output_path.stat().st_size == 0:
                raise RuntimeError(f"Forward extraction produced no output for {dataset}")
            trace_count, storage = _storage_summary(output_path)
            summaries.append(
                {
                    "dataset": dataset,
                    "status": "complete",
                    "traces": trace_count,
                    "input": input_path.as_posix(),
                    "output": output_path.as_posix(),
                    "storage": storage,
                    "execution": execution,
                }
            )
    finally:
        del model
        del tokenizer
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    summary = {
        "status": "complete",
        "forward_model": args.model_id,
        "forward_provenance": provenance,
        "generation_model": args.generation_model,
        "quantization": args.quantization,
        "router_only": args.router_only,
        "feature_schema_version": FEATURE_SCHEMA_VERSION,
        "max_geometry_tokens": args.max_geometry_tokens,
        "raw_tensors_saved": args.save_raw_tensors,
        "probe_results": None if getattr(args, "all_router_layers", False) else args.probe_results.as_posix(),
        "layer_selection": "all_router_layers" if getattr(args, "all_router_layers", False) else "fixed_probe_indices",
        "layer_indices": layer_indices,
        "excluded_probe_indices": excluded_probe_indices,
        "expert_weights_saved": False,
        "reasoning_views": modes,
        "position_reference": reference,
        "datasets": summaries,
    }
    _write_json_atomic(summary, output_root / "summary.json")
    return summaries


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Teacher-force saved generations through the matching Hugging Face MoE checkpoint"
    )
    parser.add_argument(
        "--model-id",
        default=DEFAULT_FORWARD_MODEL,
        help="Hugging Face target checkpoint matching the generation manifest",
    )
    parser.add_argument("--revision", help="Pinned forward checkpoint/tokenizer revision")
    parser.add_argument("--local-files-only", action="store_true")
    parser.add_argument("--generation-model", default=DEFAULT_GENERATION_MODEL)
    parser.add_argument("--datasets", nargs="+", choices=tuple(BENCHMARKS), default=DEFAULT_BENCHMARKS)
    parser.add_argument(
        "--generation-dir",
        type=Path,
        default=Path("results/correlation_pipeline/generation"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/correlation_pipeline/forward"),
    )
    parser.add_argument("--limit", type=int, default=None, help="Limit traces per dataset")
    parser.add_argument("--views", nargs="+", choices=("full", "class", "position"), default=None,
                        help="Opt in to versioned reasoning-span views; legacy features are retained")
    parser.add_argument("--annotation-dir", type=Path, default=None)
    parser.add_argument("--dynamics", action="store_true", help="Reduce native temporal routing before releasing raw signals")
    parser.add_argument("--position-bins", type=int, default=10)
    parser.add_argument("--top-k", type=int, default=None)
    parser.add_argument(
        "--quantization",
        choices=QUANTIZATION_CHOICES,
        default="unsloth-4bit",
    )
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--trust-remote-code", action="store_true")
    parser.add_argument(
        "--max-geometry-tokens",
        type=int,
        default=128,
        help="Maximum uniformly sampled tokens used for hidden/router geometry",
    )
    parser.add_argument(
        "--save-raw-tensors",
        action="store_true",
        help="Also persist full router/hidden tensors for a small audit run",
    )
    parser.add_argument(
        "--probe-results",
        type=Path,
        default=DEFAULT_PROBE_RESULTS,
        help="Probe results.json used to retain the union of best_by_target layers",
    )
    parser.add_argument("--all-router-layers", action="store_true",
                        help="Explicitly use every router layer instead of the fixed probe indices")
    parser.add_argument(
        "--router-only",
        action="store_true",
        help="Skip hidden-state tensors; this disables hidden/router geometry correlations.",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    args = build_parser().parse_args(argv)
    if args.max_geometry_tokens < 3:
        raise ValueError("--max-geometry-tokens must be at least 3")
    extract_all(args)


if __name__ == "__main__":
    main()
