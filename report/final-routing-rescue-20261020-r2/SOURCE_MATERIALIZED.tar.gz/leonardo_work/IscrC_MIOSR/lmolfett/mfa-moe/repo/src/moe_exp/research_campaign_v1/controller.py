"""Bounded finite Slurm orchestration, scientific receipts and automatic admission."""
from __future__ import annotations
from collections import defaultdict
import os
from pathlib import Path
import time

from .contracts import MODELS, Units, check_files, digest, load, locked, publish, require
from .scheduler import Slurm, admission, array_card, card, never_started, protected_controller, submit_card


def stage_key(stage,model="all",shard=0,threshold=0):
    return f"{stage}-{model}-{threshold:02d}-{shard:05d}"


def jobs(campaign,scheduler):
    root=Path(campaign["root"])
    records=[]
    for path in sorted((root/"submissions").glob("*/ACCEPTED.json")):
        accepted=load(path)
        value=load(root/"cards"/(accepted["card_sha256"]+".json"))
        assignments=[(str(accepted["job_id"])+"_"+str(i),sub) for i,sub in enumerate(value["array_cards"])] if value.get("array_cards") else [(accepted["job_id"],value)]
        for job_id,assignment in assignments:
            records.append({"card":assignment,"accepted":{**accepted,"job_id":job_id,
                "array_parent":accepted["job_id"] if value.get("array_cards") else None}})
    for offset in range(0,len(records),200):
        batch=records[offset:offset+200]
        observations={}
        if hasattr(scheduler,"observe_many"):
            try:observations=scheduler.observe_many([j["accepted"]["job_id"] for j in batch])
            except Exception:pass
        for j in batch:
            job_id=j["accepted"]["job_id"]
            try:
                observation=observations.get(job_id) or scheduler.observe(job_id)
            except Exception as exc:
                observation={"job_id":job_id,"terminal":False,"state":"ACCOUNTING_PENDING",
                             "error":str(exc)[:500],"billing_hours":None}
            j["accounting"]=observation
    return records


def status(campaign,scheduler=None):
    root=Path(campaign["root"])
    observed=jobs(campaign,scheduler or Slurm())
    results=[]
    for p in sorted((root/"stages").glob("*/RESULT.json")):
        results.append(load(p))
    terminal=load(root/"TERMINAL.json") if (root/"TERMINAL.json").exists() else None
    report=(root/"REPORT_COMPLETE.json").exists()
    science=load(root/"SCIENCE_COMPLETE.json")["complete"] if (root/"SCIENCE_COMPLETE.json").exists() else False
    return {"campaign_id":campaign["campaign_id"],"root":str(root),"jobs":observed,"stages":results,
        "terminal":terminal,"REPORT_COMPLETE":report,"SCIENCE_COMPLETE":science,
        "actual_local_hours":sum(j["accounting"].get("billing_hours") or 0 for j in observed)}


def _outstanding(snapshot,observed,scheduler):
    own={j["accepted"]["job_id"] for j in observed}
    reservation=sum(j["card"]["reservation_hours"] for j in observed if not j["accounting"]["terminal"])
    # Other outstanding reservations reduce the same finite spending authority.
    for job in snapshot["jobs"]:
        if job["job_id"] in own:
            continue
        import re
        text=scheduler.command(["scontrol","show","job","-o",job["job_id"]])
        fields=dict(re.findall(r"(\w+)=([^\s]+)",text))
        if fields.get("Account")!="iscrc_miosr":
            continue
        match=re.search(r"(?:^|,)billing=(\d+(?:\.\d+)?)",fields.get("TRES",fields.get("AllocTRES","")))
        require(match,"other outstanding job has no verifiable billing reservation")
        duration=fields["TimeLimit"]
        day,clock=duration.split("-",1) if "-" in duration else ("0",duration)
        hh,mm,ss=map(int,clock.split(":"))
        reservation+=float(match[1])*(int(day)*24+hh+mm/60+ss/3600)
    return reservation


def _check(campaign,scheduler,observed,*,hours,bytes_,prices=True,reserve=32):
    snapshot=scheduler.snapshot()
    hours+=_saved_cpu_residual(campaign,observed)
    return {"snapshot":snapshot,**admission(snapshot,
        baseline_consumed=campaign["authorization_baseline_consumed"],
        campaign_actual=sum(j["accounting"].get("billing_hours") or 0 for j in observed),
        outstanding=_outstanding(snapshot,observed,scheduler),residual=hours,
        output_bytes=bytes_+_saved_output_residual(campaign),prices_complete=prices,reserve_hours=reserve)}


def _saved_cpu_residual(campaign,observed):
    root=Path(campaign["root"])
    submitted={stage_key(j["card"]["stage"],j["card"]["model"],j["card"]["shard_index"],j["card"]["threshold_index"]) for j in observed}
    from .observations import pair_tasks
    hours=0.
    for model in MODELS:
        if _failure(root,"derive",model):continue
        if _stage_state(root,"supplementary",model) is None and stage_key("supplementary",model) not in submitted:hours+=12.
        pairs=pair_tasks(campaign,model)
        if not pairs:continue
        pilot=_stage_state(root,"coordination",model,pairs[0]["shard_index"])
        if pilot is None:
            if stage_key("coordination",model,pairs[0]["shard_index"]) not in submitted:hours+=12.
            continue  # First original price is a bounded measurement exception.
        if pilot["status"] not in ("complete","reused"):continue
        for pair in pairs:
            if _stage_state(root,"coordination",model,pair["shard_index"]) is None and stage_key("coordination",model,pair["shard_index"]) not in submitted:
                hours+=max(1,pilot["seconds"])*4/3600
    return hours


def _saved_output_residual(campaign):
    """Reserve uncompressed joint tables, frozen ledgers and final exports.

    Exact quota already counts committed output. Only absent artifacts enter
    this bound, so every subsequent wave protects the full saved-data scope.
    """
    root=Path(campaign["root"])
    total=0
    from .observations import pair_tasks
    for model in MODELS:
        E=campaign["models"][model]["experts"]
        for pair in pair_tasks(campaign,model):
            path=root/model/"coordination"/f"pair-{pair['shard_index']:03d}"/"RESULT.json"
            state=_stage_state(root,"coordination",model,pair["shard_index"])
            if not path.exists() and state is None:
                total+=(14*8+5*6*14*4)*E*E+4*1024**2
        if not (root/model/"SUPPLEMENTARY.json").exists() and _stage_state(root,"supplementary",model) is None:
            total+=64*1024**2
        if not (root/model/"TASKS.json").exists():
            # JSON masks are repeated only in immutable execution assignments;
            # reserve this finite metadata rather than treating it as free.
            total+=2*1024**3
    if not (root/"REPORT_COMPLETE.json").exists():total+=2*1024**3
    return total


def _stage_state(root,stage,model="all",shard=0,threshold=0):
    directory=root/"stages"/stage_key(stage,model,shard,threshold)
    return load(directory/"RESULT.json") if (directory/"RESULT.json").exists() else None


def _success(root,stage,model="all",shard=0):
    return (_stage_state(root,stage,model,shard) or {}).get("status") in ("complete","reused")


def _failure(root,stage,model="all",shard=0):
    state=_stage_state(root,stage,model,shard)
    return state is not None and state["status"] not in ("complete","reused")


def _mark(root,stage,model,status,reason,shard=0):
    return publish(root/"stages"/stage_key(stage,model,shard)/"RESULT.json",{
        "stage":stage,"model":model,"shard_index":shard,"threshold_index":0,
        "status":status,"reason":reason,"automatic_terminal_status":True})


def terminal(campaign,status_,reason):
    root=Path(campaign["root"])
    if not (root/"TERMINAL.json").exists():
        publish(root/"TERMINAL.json",{"status":status_,"reason":reason,"epoch":time.time(),
            "report_complete_is_not_science_complete":True})


def reconcile(campaign,scheduler,observed):
    root=Path(campaign["root"])
    for j in observed:
        c,a=j["card"],j["accounting"]
        if c["stage"]=="controller" or not a["terminal"]:
            continue
        directory=root/"stages"/stage_key(c["stage"],c["model"],c["shard_index"],c["threshold_index"])
        if (directory/"RESULT.json").exists():
            continue
        if never_started(a,(directory/"START.json").exists(),c["attempt"]):
            replacement=card(campaign,c["stage"],c["model"],c["shard_index"],c["threshold_index"],
                attempt=1,minutes=c["minutes"])
            if not (directory/"INFRASTRUCTURE_REPLACEMENT.json").exists():
                publish(directory/"INFRASTRUCTURE_REPLACEMENT.json",{"original":j,"replacement":replacement,
                    "proof":"zero-runtime accounting, unset Start, no Python or scientific-unit start receipt"})
            submit_card(campaign,replacement,scheduler)
        else:
            _mark(root,c["stage"],c["model"],"execution_failed",
                {"accounting":a,"scientific_redraw":False,"committed_units_retained":True},c["shard_index"])


def _measurement_forecast(campaign):
    root=Path(campaign["root"])
    hours=0.;bytes_=0;missing=[]
    for model in MODELS:
        if _failure(root,"derive",model) or _failure(root,"native",model) or _failure(root,"measure",model,0):
            continue
        tasks=load(root/model/"MEASURE_TASKS.json")["records"]
        units=Units(root/model/"measurements")
        pilot=units.state(tasks[0]["uid"])
        if (pilot or {}).get("status")!="complete":
            missing.append(model)
            continue
        # The largest original sequence prices prefill and the streamed operator;
        # charge its observed duration to every missing assignment conservatively.
        each=max(1.,pilot["seconds"])
        pending=[r["task_index"] for r in tasks if units.state(r["uid"]) is None]
        per_shard=max(1,int((22*3600-pilot["load_seconds"])/each))
        shards=[pending[i:i+per_shard] for i in range(0,len(pending),per_shard)]
        publish(root/model/"MEASURE_SHARDS.json",{"shards":shards,"price_uid":pilot["uid"],
            "seconds_per_assignment_upper":each,"load_seconds":pilot["load_seconds"],"all_original_sources":True})
        hours+=(len(pending)*each+len(shards)*pilot["load_seconds"])*16/3600
        bytes_+=len(pending)*pilot["artifact"]["bytes"]
    return hours,bytes_,missing


def _production_forecast(campaign,freeze_shards=True):
    root=Path(campaign["root"])
    residual=0.;storage=0;missing=[]
    for model in MODELS:
        if not _success(root,"price",model):
            upstream_failed=any(_failure(root,s,model) for s in ("derive","native","freeze","qualify","price")) or _failure(root,"measure",model,0)
            if not upstream_failed:
                missing.append(model)
            continue
        table=load(root/model/"TASKS.json")
        prices={p["role"]:p for p in load(root/model/"PRICES.json")["records"]}
        units=Units(root/model/"executions")
        scores=Units(root/model/"scores")
        # Each forecast reads execution receipts once and retains only terminal
        # statuses, rather than keeping token captures or re-reading them for
        # every role and annotator bound.
        execution_states={}
        for r in table["records"]:
            state=units.state(r["uid"])
            execution_states[r["uid"]]=state.get("status") if state else None
        failed_shapes=set(load(root/model/"QUALIFICATION.json").get("failed_shape_keys",[]))
        residual+=sum(scores.state(r["uid"]) is None for r in table["records"])*30*4/3600
        if not _stage_state(root,"contexts",model):residual+=12.
        grouped=defaultdict(list)
        for row in table["records"]:
            if execution_states[row["uid"]] is not None:
                continue
            from .workers import mask_shape
            shape=mask_shape(campaign,model,row["mask"]) if row["mask"] is not None else None
            if shape in failed_shapes:
                continue
            role="memory:"+shape if shape else "causal" if row["action"] is not None else "reused_native"
            grouped[role].append(row)
        shards=[]
        for role,rows in sorted(grouped.items()):
            if role=="reused_native":
                # Native branches share saved outcome and capture records.
                each,load_seconds,outbytes=2.,0.,200000
            elif role not in prices:
                missing.append(f"{model}:{role}");continue
            else:
                p=prices[role]
                rate=p["seconds"]/max(1,p["generated_tokens"])
                # Native cumulative allowances bound every remaining task. This
                # deliberately prices long continuations rather than assuming an
                # intervention cannot extend them.
                each=max(p["seconds"],max(r["cap"] for r in rows)*rate)
                load_seconds=p["load_seconds"]
                outbytes=p["output_bytes"]/max(1,p["generated_tokens"])*max(r["cap"] for r in rows)
            batches=defaultdict(list)
            for r in rows:
                batches[digest(r["mask"])].append(r["task_index"])
            size=max(1,int((22*3600-load_seconds)/max(1,each)))
            for batch in batches.values():
                shards.extend(batch[i:i+size] for i in range(0,len(batch),size))
            residual+=(len(rows)*each+sum((len(b)+size-1)//size for b in batches.values())*load_seconds)*16/3600
            storage+=len(rows)*outbytes
        if freeze_shards:
            publish(root/model/"EXECUTION_SHARDS.json",{"shards":shards,"prices_sha256":load(root/model/"PRICES.json")["sha256"],
                "complete_residual_forecast":True,"native_cumulative_allowances_used":True})
        # Bound all sentence contexts and the original annotator workload before
        # admitting production. Missing reader prices reject admission; no guessed
        # annotator seconds silently permit target generations.
        reader=root/"ANNOTATOR_PRICE.json"
        if not reader.exists() or load(reader).get("status")!="complete":
            missing.append("original-annotator")
        else:
            price=load(reader)
            maximum_sentences=sum(min(r["cap"],r["window"])+1 for r in table["records"] if r["source"]["prefix_tokens"] and execution_states[r["uid"]] is None)
            if not (root/model/"CONTEXTS.json").exists():
                maximum_sentences+=sum(min(r["cap"],r["window"])+1 for r in table["records"] if r["source"]["prefix_tokens"] and
                    execution_states[r["uid"]]=="complete")
            annotation_tasks=root/model/"ANNOTATION_TASKS.json"
            if annotation_tasks.exists():
                annotations=Units(root/model/"annotations")
                maximum_sentences+=sum(annotations.state(r["uid"]) is None for r in load(annotation_tasks)["records"])
            # One sentence can be one token; measured original maximum-input
            # reader batch bounds every fixed draw without shortening its cap.
            per_job=max(1,int((22*3600-price.get("load_seconds",0))/price["seconds_per_context_upper"]))
            jobs_needed=(maximum_sentences+per_job-1)//per_job
            residual+=(maximum_sentences*price["seconds_per_context_upper"]+jobs_needed*price.get("load_seconds",0))*16/3600
            storage+=maximum_sentences*price["bytes_per_context_upper"]
    return residual,int(storage),sorted(set(missing))


def ready(campaign,scheduler,observed):
    root=Path(campaign["root"])
    work=[]
    def want(stage,model="all",shard=0,minutes=None):
        key=stage_key(stage,model,shard)
        if _stage_state(root,stage,model,shard) is not None:
            return
        if any(stage_key(j["card"]["stage"],j["card"]["model"],j["card"]["shard_index"],j["card"]["threshold_index"])==key for j in observed):
            return
        work.append(card(campaign,stage,model,shard,minutes=minutes))
    def saved_work():
        from .observations import pair_tasks
        pilots=[];residual=0.
        for m in MODELS:
            if not _success(root,"derive",m):continue
            want("supplementary",m,minutes=180)
            pairs=pair_tasks(campaign,m)
            if not pairs:continue
            pilot=_stage_state(root,"coordination",m,pairs[0]["shard_index"])
            pilots.append((m,pairs,pilot))
            if pilot is None:want("coordination",m,pairs[0]["shard_index"],minutes=180)
            elif pilot["status"] in ("complete","reused"):
                residual+=sum(_stage_state(root,"coordination",m,p["shard_index"]) is None for p in pairs)*max(1,pilot["seconds"])*4/3600
        if any(p is None for m,pairs,p in pilots):return
        if not (root/"SAVED_COORDINATION_ADMISSION.json").exists():
            check=_check(campaign,scheduler,observed,hours=0,bytes_=0)
            publish(root/"SAVED_COORDINATION_ADMISSION.json",{"retained_first_original_pair_per_model":True,**check})
        admitted=load(root/"SAVED_COORDINATION_ADMISSION.json")["admitted"]
        for m,pairs,pilot in pilots:
            supported=pilot["status"] in ("complete","reused")
            for pair in pairs:
                if _stage_state(root,"coordination",m,pair["shard_index"]) is not None:continue
                if admitted and supported:
                    import math
                    minutes=min(240,max(30,math.ceil(pilot["seconds"]*1.25/60)+5))
                    want("coordination",m,pair["shard_index"],minutes=minutes)
                else:
                    _mark(root,"coordination",m,"resource_limited" if not admitted else "upstream_unavailable",
                        "complete saved-data workload failed admission" if not admitted else "original pair operator price unavailable",pair["shard_index"])
    if (root/"REPORT_COMPLETE.json").exists():
        return []
    if (root/"TERMINAL.json").exists():
        if _success(root,"resolve"):
            saved_work()
        if work:
            return work
        if not any(not j["accounting"]["terminal"] and j["card"]["stage"] not in ("controller","snapshot") for j in observed):
            want("closeout",minutes=180)
        return work
    if not _success(root,"resolve"):
        if _failure(root,"resolve"):
            terminal(campaign,"upstream_unavailable","source resolution failed; no replacements scheduled")
            want("closeout",minutes=180)
        else:
            want("resolve",minutes=180)
        return work
    for model in MODELS:
        want("derive",model,minutes=180)
    if not all(_stage_state(root,"derive",m) for m in MODELS):
        return work
    # Independent saved-data panels are derived without generating another trace.
    saved_work()
    for model in MODELS:
        if _success(root,"derive",model):
            want("native",model,minutes=180)
    for model in MODELS:
        if _success(root,"native",model):
            want("measure",model,0,minutes=120)
    if not all(_failure(root,"derive",m) or _failure(root,"native",m) or _stage_state(root,"measure",m,0) for m in MODELS):
        return work
    if not (root/"PREPARATION_ADMISSION.json").exists():
        hours,bytes_,missing=_measurement_forecast(campaign)
        # Qualification and first role prices are bounded measurement exceptions,
        # not an unpriced final-production admission.
        check=_check(campaign,scheduler,observed,hours=hours,bytes_=bytes_,prices=not missing)
        publish(root/"PREPARATION_ADMISSION.json",{"scope":"all residual saved native measurements",**check})
        if not check["admitted"]:
            terminal(campaign,"resource_limited",check)
            return work
    for model in MODELS:
        if _failure(root,"derive",model) or _failure(root,"native",model) or _failure(root,"measure",model,0):
            continue
        shards=load(root/model/"MEASURE_SHARDS.json")["shards"]
        for i in range(1,len(shards)+1):
            want("measure",model,i,minutes=1440)
        if not all(_stage_state(root,"measure",model,i) for i in range(len(shards)+1)):
            continue
        if any(_failure(root,"measure",model,i) for i in range(len(shards)+1)):
            _mark(root,"freeze",model,"upstream_unavailable","missing native measurement remains terminal")
            continue
        for i in range(1,6):
            want("freeze",model,i,minutes=180)
        if not all(_stage_state(root,"freeze",model,i) for i in range(1,6)):
            continue
        if any(_failure(root,"freeze",model,i) for i in range(1,6)):
            _mark(root,"freeze",model,"upstream_unavailable","discovery calibration failed")
            continue
        want("freeze",model,0)
        if not _success(root,"freeze",model):
            continue
        from .workers import qualification_rows
        qualification=qualification_rows(campaign,model)["records"]
        for r in qualification:
            want("qualify",model,r["shard_index"],minutes=120)
        if not all(_stage_state(root,"qualify",model,r["shard_index"]) for r in qualification):
            continue
        want("qualify",model,0)
        if _success(root,"qualify",model):
            from .workers import price_rows
            prices=price_rows(campaign,model)["records"]
            for r in prices:
                want("price",model,r["shard_index"],minutes=1440)
            if all(_stage_state(root,"price",model,r["shard_index"]) for r in prices):
                want("price",model,0)
    finished=lambda m: _failure(root,"derive",m) or _failure(root,"native",m) or _failure(root,"measure",m,0) or _failure(root,"freeze",m) or _failure(root,"qualify",m) or _stage_state(root,"price",m)
    if not all(finished(m) for m in MODELS):
        return work
    if not any(_success(root,"price",m) for m in MODELS):
        terminal(campaign,"upstream_unavailable","no model supplied a qualified retained production role price")
        return work
    # Price the first genuinely missing original annotator context retained from
    # the original target-role measurement, then include it in residual tasks.
    if not (root/"ANNOTATOR_PRICE.json").exists():
        want("reader_price",minutes=1440)
        return work
    if not (root/"ADMISSION.json").exists():
        from .observations import pair_tasks
        if any(_success(root,"derive",m) and pair_tasks(campaign,m) and
            _stage_state(root,"coordination",m,1) is None for m in MODELS):return work
        hours,bytes_,missing=_production_forecast(campaign)
        check=_check(campaign,scheduler,observed,hours=hours,bytes_=bytes_,prices=not missing)
        publish(root/"ADMISSION.json",{"required_missing_prices":missing,**check})
        if not check["admitted"]:
            terminal(campaign,"resource_limited",check)
            return work
    for model in MODELS:
        if not _success(root,"price",model):
            continue
        shards=load(root/model/"EXECUTION_SHARDS.json")["shards"]
        for i in range(len(shards)):
            want("execute",model,i,minutes=1440)
        if not all(_stage_state(root,"execute",model,i) for i in range(len(shards))):
            continue
        fragments=sorted((root/model/"execution_fragments").glob("*.json"))
        for p in fragments:
            fragment=load(p);want("execute",model,fragment["shard_index"],minutes=1440)
        if not all(_stage_state(root,"execute",model,load(p)["shard_index"]) for p in fragments):continue
        table=load(root/model/"TASKS.json")["records"]
        units=Units(root/model/"executions")
        uncovered=[r for r in table if units.state(r["uid"]) is None]
        if uncovered:
            # Later fragments cover only untouched frozen assignments, never
            # started failures or an alternative source/dose. The finite graph
            # can expand by at most the number of original execution rows.
            grouped=defaultdict(list)
            for row in uncovered:grouped[digest(row["mask"])].append(row["task_index"])
            size=max((len(s) for s in shards),default=1)
            index=len(shards)+len(fragments)
            for group in grouped.values():
                for start in range(0,len(group),size):
                    publish(root/model/"execution_fragments"/f"{index:06d}.json",{
                        "shard_index":index,"indices":group[start:start+size],"only_proven_unstarted_frozen_units":True})
                    want("execute",model,index,minutes=1440);index+=1
            continue
        want("contexts",model,minutes=180)
        scoreplan=root/model/"SCORE_SHARDS.json"
        if not scoreplan.exists():
            scores=Units(root/model/"scores")
            table=load(root/model/"TASKS.json")["records"]
            pending=[r["task_index"] for r in table if scores.state(r["uid"]) is None]
            publish(scoreplan,{"shards":[pending[i:i+256] for i in range(0,len(pending),256)],
                "maximum_assignment_seconds":30,"original_strict_contract":True})
        scoring=load(scoreplan)["shards"]
        for i in range(len(scoring)):want("score",model,i+1,minutes=180)
        if all(_stage_state(root,"score",model,i+1) for i in range(len(scoring))):want("score",model,0,minutes=30)
        if _success(root,"contexts",model):
            table=load(root/model/"ANNOTATION_TASKS.json")["records"]
            count=max(1,int(22*3600/load(root/"ANNOTATOR_PRICE.json")["seconds_per_context_upper"]))
            slices=[list(range(i,min(i+count,len(table)))) for i in range(0,len(table),count)]
            publish(root/model/"ANNOTATION_SHARDS.json",{"shards":slices})
            for i in range(len(slices)):
                want("annotate",model,i,minutes=1440)
    all_finished=True
    for model in MODELS:
        if not _success(root,"price",model):
            continue
        if not _stage_state(root,"score",model) or not _stage_state(root,"contexts",model):
            all_finished=False;continue
        if _success(root,"contexts",model):
            count=len(load(root/model/"ANNOTATION_SHARDS.json")["shards"])
            all_finished &= all(_stage_state(root,"annotate",model,i) for i in range(count))
    if all_finished:
        terminal(campaign,"production_terminal","all admitted independent assignments have terminal evidence")
    return work


def retire_guards(campaign,scheduler,*,before_generation=None,all_=False):
    root=Path(campaign["root"])
    for p in sorted((root/"handoffs").glob("*.json")):
        handoff=load(p)
        if not all_ and handoff["generation"]>=before_generation:
            continue
        for guard in handoff["guards"]:
            proofpath=root/"guard_retirements"/(guard["job_id"]+".json")
            if proofpath.exists():
                continue
            observation=scheduler.observe(guard["job_id"])
            if observation["terminal"] or observation["start"] not in ("None","Unknown","N/A","",None):
                continue
            require(observation["elapsed_seconds"]==0,"running failure guard cannot be superseded")
            scheduler.command(["scancel",guard["job_id"]])
            after=scheduler.observe(guard["job_id"])
            require(after["state"]=="CANCELLED" and after["elapsed_seconds"]==0,"guard retirement not verified")
            publish(proofpath,{"before":observation,"after":after,"protected_successor_or_terminal_report":True})


def launch(campaign,scheduler=None):
    scheduler=scheduler or Slurm()
    check_files(campaign["code_files"])
    root=Path(campaign["root"])
    with locked(root,"controller"):
        if (root/"LAUNCH.json").exists():
            return load(root/"LAUNCH.json")
        snapshot=scheduler.snapshot()
        require(len([j for j in snapshot["jobs"] if j["partition"]=="lrd_all_serial"])<=5,"insufficient serial submission capacity for protected launch")
        check=_check(campaign,scheduler,[],hours=7*32.+24.,bytes_=512*1024**2)
        require(check["admitted"],"bounded source resolution and retained measurements cannot be admitted")
        initial=card(campaign,"resolve",minutes=180)
        accepted=submit_card(campaign,initial,scheduler)
        milestone=submit_card(campaign,card(campaign,"snapshot",minutes=180,begin="2026-10-15T21:59:59"),scheduler)
        handoff=protected_controller(campaign,scheduler,generation=0,wait_ids=[accepted["job_id"]])
        return publish(root/"LAUNCH.json",{"campaign_id":campaign["campaign_id"],"initial_jobs":[accepted,milestone,*[handoff["primary"],*handoff["guards"]]],
            "output_location":campaign["root"],"snapshot":snapshot,"bounded_initial_admission":check,
            "complete_finite_graph_registered":True})


def control(campaign,value,scheduler=None):
    scheduler=scheduler or Slurm()
    root=Path(campaign["root"])
    check_files(campaign["code_files"])
    with locked(root,"controller"):
        observed=jobs(campaign,scheduler)
        reconcile(campaign,scheduler,observed)
        if (root/"REPORT_COMPLETE.json").exists():
            refreshed=jobs(campaign,scheduler)
            milestone=[j["accepted"]["job_id"] for j in refreshed if j["card"]["stage"]=="snapshot" and not j["accounting"]["terminal"]]
            if milestone:
                current=os.environ.get("SLURM_JOB_ID")
                generation=value["generation"]+1
                handoff=protected_controller(campaign,scheduler,generation=generation,wait_ids=milestone+([current] if current else []))
                retire_guards(campaign,scheduler,before_generation=generation)
                return {"status":"complete","REPORT_COMPLETE":True,"milestone_owner":handoff}
            retire_guards(campaign,scheduler,all_=True)
            if not (root/"FINAL_ACCOUNTING.json").exists():
                publish(root/"FINAL_ACCOUNTING.json",{"observed":status(campaign,scheduler),
                    "scientific_and_milestone_jobs_terminal":True,"current_final_controller_charge_pending":True})
            return {"status":"complete","REPORT_COMPLETE":True}
        work=ready(campaign,scheduler,observed)
        if (root/"ADMISSION.json").exists() and load(root/"ADMISSION.json")["admitted"] and not (root/"TERMINAL.json").exists():
            hours,bytes_,missing=_production_forecast(campaign,freeze_shards=False)
            recheck=_check(campaign,scheduler,observed,hours=hours,bytes_=bytes_,prices=not missing)
            if not recheck["admitted"]:
                terminal(campaign,"resource_limited",recheck)
                work=ready(campaign,scheduler,observed)
        priorities={"derive":0,"native":1,"measure":2,"freeze":3,"qualify":4,"price":5,
            "reader_price":6,"execute":7,"contexts":8,"score":8,"annotate":9,"supplementary":10,"coordination":11}
        work.sort(key=lambda c:(priorities.get(c["stage"],0),c["model"],c["shard_index"]))
        snapshot=scheduler.snapshot()
        serial=len([j for j in snapshot["jobs"] if j["partition"]=="lrd_all_serial"])
        gpu=len([j for j in snapshot["jobs"] if j["partition"]=="boost_usr_prod"])
        accepted=[];wave_cards=[]
        for c in work:
            if c["partition"]=="lrd_all_serial":
                if serial>=7:
                    continue
                serial+=1
            elif gpu>=24:
                continue
            else:
                gpu+=1
            # Live accounting and exact quota are rechecked before each wave.
            wave=_check(campaign,scheduler,observed,hours=c["reservation_hours"]+sum(x["reservation_hours"] for x in wave_cards),bytes_=0)
            if not wave["admitted"] and c["stage"]!="closeout":
                if wave_cards:
                    break  # A bounded smaller wave owns capacity deferral.
                terminal(campaign,"resource_limited",wave)
                if c["stage"] in ("coordination","supplementary"):
                    for unavailable in work:
                        if unavailable["stage"] in ("coordination","supplementary"):
                            _mark(root,unavailable["stage"],unavailable["model"],"resource_limited",wave,unavailable["shard_index"])
                break
            wave_cards.append(c)
        grouped=defaultdict(list)
        for c in wave_cards:
            grouped[c["stage"],c["model"],c["minutes"]].append(c)
        for group in grouped.values():
            parent=array_card(group) if len(group)>1 else group[0]
            accepted.append(submit_card(campaign,parent,scheduler))
        refreshed=jobs(campaign,scheduler)
        active=[j["accepted"]["job_id"] for j in refreshed if not j["accounting"]["terminal"] and j["card"]["stage"] not in ("controller","snapshot")]
        # An afterany successor owns completion; bounded begin deferral owns
        # scheduler saturation without a login daemon or repeated watchdog.
        current=os.environ.get("SLURM_JOB_ID")
        wait_ids=active+([current] if current else [])
        begin=None if active else "now+5minutes"
        generation=value["generation"]+1
        if generation>1024:
            terminal(campaign,"resource_limited","finite controller handoff capacity exhausted")
            from .export import closeout
            closeout(campaign)
            return {"status":"complete","REPORT_COMPLETE":True}
        handoff=protected_controller(campaign,scheduler,generation=generation,wait_ids=wait_ids,begin=begin)
        retire_guards(campaign,scheduler,before_generation=generation)
        return {"status":"complete","submitted":accepted,"successor":handoff,
            "scheduler_capacity_deferred":len(work)-len(accepted)}
