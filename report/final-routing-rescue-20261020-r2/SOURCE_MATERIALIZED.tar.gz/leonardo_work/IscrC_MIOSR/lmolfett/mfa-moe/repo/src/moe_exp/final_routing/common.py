"""Small immutable receipts and explicit execution states; no GPU imports."""
from __future__ import annotations

from contextlib import contextmanager
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
import time

REPO = Path(__file__).resolve().parents[3]
WORK = Path('/leonardo_work/IscrC_MIOSR/lmolfett')
HOME = Path('/leonardo/home/userexternal/lmolfett')
FAST = Path('/leonardo_scratch/fast/IscrC_MIOSR/lmolfett/mfa-moe/campaign-runs')
CLASSES = ('Read', 'Analyze', 'Plan', 'Implement', 'Explore', 'Verify', 'Monitor')
BENCHMARKS = ('aime24', 'aime25', 'amc23', 'math500', 'minerva', 'olympiad')
ARMS = ('native', 'target_activate', 'target_deactivate', 'random_activate', 'random_deactivate')
MODELS = ('gpt', 'nemotron', 'qwen35', 'qwen36', 'gemma', 'glm', 'qwen330b', 'lfm25')
TERMINAL = {'complete', 'unknown', 'execution_failed', 'upstream_unavailable',
            'insufficient_support', 'resource_limited'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def clean(value):
    if hasattr(value, 'tolist'):
        value = value.tolist()
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def canonical(value):
    return json.dumps(clean(value), sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    with Path(path).open() as stream:
        return json.load(stream)


def private(path):
    path = Path(path).resolve()
    require(any(path.is_relative_to(p) for p in (WORK, HOME, FAST)),
            f'path outside authorized private storage: {path}')
    return path


@contextmanager
def locked(root, name='journal'):
    root = private(root)
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (root / (digest(name) + '.lock')).open('a') as stream:
        os.chmod(stream.name, 0o600)
        fcntl.flock(stream, fcntl.LOCK_EX)
        yield


def publish(path, value):
    """Atomic, exclusive publication. An existing receipt must match exactly."""
    path = private(path)
    payload = clean({k: v for k, v in value.items() if k != 'sha256'})
    payload['sha256'] = digest(payload)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.exists():
        require(load(path) == payload, f'immutable receipt conflict: {path}')
        return payload
    fd, tmp = tempfile.mkstemp(prefix='.pending-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(canonical(payload) + b'\n')
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(tmp, path)
        except FileExistsError:
            require(load(path) == payload, f'concurrent receipt conflict: {path}')
        require(load(path) == payload, f'publication readback differs: {path}')
    finally:
        Path(tmp).unlink(missing_ok=True)
    return payload


def verified(path):
    value = load(path)
    require(value.get('sha256') == digest({k: v for k, v in value.items() if k != 'sha256'}),
            f'receipt hash differs: {path}')
    return value


def check_files(binding):
    for path, expected in binding.items():
        require(Path(path).is_file() and file_sha(path) == expected, f'bound input changed: {path}')


class Units:
    """Untouched -> intent -> admitted -> output -> result; no ambiguous redraw."""
    def __init__(self, root):
        self.root = private(root)

    def folder(self, uid):
        require(len(uid) == 64 and all(c in '0123456789abcdef' for c in uid), 'invalid execution ID')
        return self.root / uid

    def state(self, uid):
        folder = self.folder(uid)
        if (folder / 'RESULT.json').exists():
            return verified(folder / 'RESULT.json')
        if (folder / 'OUTPUT.json').exists():
            return {'status': 'output', 'path': str(folder / 'OUTPUT.json')}
        if (folder / 'INTENT.json').exists():
            return {'status': 'unknown', 'ambiguous_admission': True,
                    'admitted_receipt': (folder / 'ADMITTED.json').exists()}
        return None

    def intent(self, row, job_id):
        with locked(self.root, row['uid']):
            if self.state(row['uid']) is not None:
                return False
            publish(self.folder(row['uid']) / 'INTENT.json',
                    {'uid': row['uid'], 'assignment_sha256': digest(row),
                     'job_id': str(job_id), 'time': time.time()})
            return True

    def admitted(self, row, job_id):
        return publish(self.folder(row['uid']) / 'ADMITTED.json',
                       {'uid': row['uid'], 'assignment_sha256': digest(row), 'job_id': str(job_id)})

    def output(self, row, value):
        return publish(self.folder(row['uid']) / 'OUTPUT.json',
                       {'uid': row['uid'], 'assignment_sha256': digest(row), **value})

    def commit(self, row, value):
        require(self.state(row['uid']) is not None, 'cannot commit an untouched execution')
        return publish(self.folder(row['uid']) / 'RESULT.json',
                       {'uid': row['uid'], 'assignment_sha256': digest(row), **value})
